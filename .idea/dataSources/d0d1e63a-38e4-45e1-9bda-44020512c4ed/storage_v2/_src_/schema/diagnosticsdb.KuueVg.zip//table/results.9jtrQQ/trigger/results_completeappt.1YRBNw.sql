create definer = root@localhost trigger Results_CompleteAppt
    after update
    on results
    for each row
BEGIN
    -- Declare variables to count results with 'Pending' and 'Inconclusive' status
    DECLARE not_done INT;
    DECLARE inconclusive_found INT;

    -- Check if there are any results with status 'Pending' for the same appointment_id
    SELECT COUNT(*) INTO not_done
    FROM Results r
    WHERE appointment_id = NEW.appointment_id
    AND status = 'Pending';

    -- Check if there is at least one result with status 'Inconclusive' for the same appointment_id
    SELECT COUNT(*) INTO inconclusive_found
    FROM Results r
    WHERE appointment_id = NEW.appointment_id
    AND outcome = 'Inconclusive';

    -- If all tests are done (no 'Pending') and there are no inconclusive results, update the appointment status to 'Completed'
    IF not_done = 0 THEN
        IF inconclusive_found > 0 THEN
            UPDATE Appointments
            SET status = 'Completed (w/ Follow-up Advised)'
            WHERE appointment_id = NEW.appointment_id;
        ELSE
            UPDATE Appointments
            SET status = 'Completed'
            WHERE appointment_id = NEW.appointment_id;
        END IF;
    END IF;
END;

