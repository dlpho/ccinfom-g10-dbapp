create
    definer = root@localhost procedure get_patient_results(IN patient_id int)
BEGIN
	SELECT a.order_date, r.*
    FROM Appointments a
    JOIN Results r ON a.appointment_id = a.appointment_id
    ORDER BY a.order_date ASC;
END;

