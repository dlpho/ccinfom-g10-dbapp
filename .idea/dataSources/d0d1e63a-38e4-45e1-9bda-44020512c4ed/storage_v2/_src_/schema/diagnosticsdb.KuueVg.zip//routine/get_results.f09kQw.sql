create
    definer = root@localhost procedure get_results(IN id int)
BEGIN
	SELECT *
    FROM Results
    WHERE appointment_id = id;
END;

