create definer = root@localhost trigger Results_CancelAppt
    after update
    on results
    for each row
BEGIN
    -- Declare a variable to count cancelled results
    DECLARE cancelled_count INT;
    DECLARE total_tests INT;

    -- Get the number of cancelled results for the same appointment_id
    SELECT COUNT(*) INTO cancelled_count
    FROM Results r
    WHERE r.appointment_id = NEW.appointment_id
    AND r.status = 'Canceled';

    -- Get the number of tests in the appointment
    SELECT num_tests INTO total_tests
    FROM Appointments
    WHERE appointment_id = NEW.appointment_id;

    -- If the number of cancelled results equals the number of tests, update the appointment status to 'Cancelled'
    IF cancelled_count = total_tests THEN
        UPDATE Appointments
        SET status = 'Canceled'
        WHERE appointment_id = NEW.appointment_id;
    END IF;
END;

