create definer = root@localhost trigger Appointments_Limit1PerDay
    before insert
    on appointments
    for each row
BEGIN
    -- Check if there is already an appointment with the same patient_id and scheduled_date
    DECLARE existing_count INT;

    -- Query to count appointments with the same patient_id and scheduled_date
    SELECT COUNT(*) INTO existing_count
    FROM `Appointments`
    WHERE `patient_id` = NEW.patient_id
    AND DATE(`scheduled_date`) = DATE(NEW.scheduled_date);

    -- If an appointment already exists for the same patient on the same day, prevent the insert
    IF existing_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Patient already has an appointment scheduled for this day.';
    END IF;
END;

