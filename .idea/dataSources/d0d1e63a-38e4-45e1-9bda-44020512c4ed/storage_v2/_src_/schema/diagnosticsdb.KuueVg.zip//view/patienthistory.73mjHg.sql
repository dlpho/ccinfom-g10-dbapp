create definer = root@localhost view patienthistory as
select `p`.`patient_id`                                                                     AS `patient_id`,
       upper(concat(`p`.`last_name`, ', ', `p`.`first_name`, ' (', `p`.`middle_name`, ')')) AS `fullname`,
       cast(`a`.`test_date` as date)                                                        AS `test_date`,
       cast((`a`.`test_date` + interval `t`.`days_valid` day) as date)                      AS `valid_until`,
       `t`.`test_name`                                                                      AS `test_name`,
       `r`.`outcome`                                                                        AS `outcome`,
       `r`.`comments`                                                                       AS `comments`
from (((`diagnosticsdb`.`patients` `p` join `diagnosticsdb`.`appointments` `a`
        on ((`p`.`patient_id` = `a`.`patient_id`))) join `diagnosticsdb`.`results` `r`
       on ((`a`.`appointment_id` = `r`.`appointment_id`))) join `diagnosticsdb`.`tests` `t`
      on ((`t`.`test_type` = `r`.`test_type`)))
where (`r`.`status` = 'Completed')
group by `p`.`patient_id`, `a`.`test_date`, `t`.`test_name`, `r`.`outcome`, `r`.`comments`
order by `p`.`patient_id`, `a`.`test_date`;

