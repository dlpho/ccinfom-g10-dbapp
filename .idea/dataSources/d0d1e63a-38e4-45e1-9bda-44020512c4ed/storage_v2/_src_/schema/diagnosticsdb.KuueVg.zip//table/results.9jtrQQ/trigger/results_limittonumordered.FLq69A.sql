create definer = root@localhost trigger Results_LimitToNumOrdered
    before insert
    on results
    for each row
BEGIN
    DECLARE ordered_tests INT;

    -- Get the number of tests ordered for the appointment
    SELECT num_tests INTO ordered_tests
    FROM Appointments
    WHERE appointment_id = NEW.appointment_id;

    -- Check if the number of existing test results for this appointment exceeds the limit
    IF (SELECT COUNT(*) FROM Results WHERE appointment_id = NEW.appointment_id) >= ordered_tests THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot add more test results than the number of tests ordered for this appointment';
    END IF;
END;

