create definer = root@localhost trigger Payments_ApptCanceled
    before insert
    on payments
    for each row
BEGIN
    -- Declare a variable to hold the Appointment status
    DECLARE appointment_status VARCHAR(255);

    -- Get the status of the Appointment associated with the payment
    SELECT status INTO appointment_status
    FROM Appointments
    WHERE appointment_id = NEW.appointment_id;

    -- If the Appointment status is 'Cancelled', signal an error and prevent payment insertion
    IF appointment_status = 'Canceled' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot make payment. Appointment status is Cancelled.';
    END IF;
END;

