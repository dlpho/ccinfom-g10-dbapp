create definer = root@localhost trigger Payments_CompleteAppt
    after update
    on payments
    for each row
BEGIN
    -- Check if payment_method has changed and the new payment_method is not 'N/A'
    IF OLD.payment_method != NEW.payment_method AND NEW.payment_method != 'N/A' THEN
        -- Update the current Payments record with the current date
        UPDATE Payments
        SET date = NOW()
        WHERE appointment_id = NEW.appointment_id;
        
        -- Update the Appointments status to 'Completed'
        UPDATE Appointments
        SET status = 'Completed'
        WHERE appointment_id = NEW.appointment_id;
    END IF;
END;

