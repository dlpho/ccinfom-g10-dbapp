create definer = root@localhost trigger Appointments_MakePayment
    after update
    on appointments
    for each row
BEGIN
	DECLARE total_cost DECIMAL(7,2);

    IF NEW.status = 'Completed' AND OLD.status != 'Completed' THEN
		-- Compute the total cost from the Results table
        
		SELECT SUM(t.test_cost) INTO total_cost
		FROM Results r
		JOIN Tests t ON t.test_type = r.test_type
		WHERE appointment_id = NEW.appointment_id AND r.status LIKE 'Completed%';	
		
        -- Create payment entry
        INSERT INTO `Payments` (total_cost, appointment_id)
        VALUES (total_cost, NEW.appointment_id);
        
        UPDATE appointments
        SET status = 'Pending Payment'
        WHERE appointment_id = NEW.appointment_id;
        
    END IF;
END;

