create
    definer = root@localhost procedure get_appointments(IN id int)
BEGIN
	SELECT *
    FROM Appointments
    WHERE patient_id = id;
END;

