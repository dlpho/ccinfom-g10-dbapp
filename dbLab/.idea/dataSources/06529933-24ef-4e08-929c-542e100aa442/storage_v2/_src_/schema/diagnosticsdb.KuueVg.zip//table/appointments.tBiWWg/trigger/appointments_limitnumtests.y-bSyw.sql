create definer = root@localhost trigger Appointments_LimitNumTests
    before insert
    on appointments
    for each row
BEGIN
    -- Check if num_tests is between 1 and 5
    IF NEW.num_tests < 1 OR NEW.num_tests > 5 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'num_tests must be between 1 and 5';
    END IF;
END;

