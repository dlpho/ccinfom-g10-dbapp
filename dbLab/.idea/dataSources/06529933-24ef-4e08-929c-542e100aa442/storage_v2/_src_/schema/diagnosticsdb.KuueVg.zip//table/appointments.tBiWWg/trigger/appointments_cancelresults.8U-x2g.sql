create definer = root@localhost trigger Appointments_CancelResults
    after update
    on appointments
    for each row
BEGIN
    -- Check if the appointment status is updated to "Cancelled"
    IF NEW.status = 'Cancelled' AND OLD.status != 'Cancelled' THEN
        -- Update the related results' status to "Cancelled"
        UPDATE `Results`
        SET status = 'Cancelled'
        WHERE appointment_id = NEW.appointment_id;
    END IF;
END;

