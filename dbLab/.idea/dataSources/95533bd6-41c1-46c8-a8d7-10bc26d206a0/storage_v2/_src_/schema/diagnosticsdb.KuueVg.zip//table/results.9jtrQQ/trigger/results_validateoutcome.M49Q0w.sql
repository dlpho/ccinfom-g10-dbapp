create definer = root@localhost trigger Results_ValidateOutcome
    before insert
    on results
    for each row
BEGIN
    -- Automatically adjust outcome for Pending
    IF NEW.status = 'Pending' THEN
        SET NEW.outcome = 'N/A';
    END IF;

    -- Automatically adjust outcome for Canceled
    IF NEW.status = 'Canceled' THEN
        SET NEW.outcome = 'N/A';
    END IF;

    -- Prevent Completed with N/A outcome
    IF NEW.status = 'Completed' AND NEW.outcome = 'N/A' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Outcome cannot be N/A when the status is Completed';
    END IF;
END;

