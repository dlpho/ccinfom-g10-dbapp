create definer = root@localhost trigger REF_InsuranceInfo_Pct
    before insert
    on ref_insuranceinfo
    for each row
BEGIN
    -- Check if the coverage_rate is between 0 and 1 (exclusive 0, inclusive 1)
    IF NEW.pct_coverage <= 0 OR NEW.pct_coverage >= 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Coverage rate must be between 0 (exclusive) and 1 (exclusive)';
    END IF;
END;

