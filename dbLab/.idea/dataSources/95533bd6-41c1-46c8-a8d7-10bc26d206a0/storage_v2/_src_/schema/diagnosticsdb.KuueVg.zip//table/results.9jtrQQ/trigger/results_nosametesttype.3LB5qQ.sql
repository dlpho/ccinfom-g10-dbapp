create definer = root@localhost trigger Results_NoSameTestType
    before insert
    on results
    for each row
BEGIN
    -- Check if the test_type for the given appointment_id already exists in the Results table
    DECLARE existing_count INT;

    -- Query to count the number of results with the same appointment_id and test_type
    SELECT COUNT(*) INTO existing_count
    FROM `Results`
    WHERE `appointment_id` = NEW.appointment_id
    AND `test_type` = NEW.test_type;

    -- If there is already a result with the same appointment_id and test_type, prevent the insert
    IF existing_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'A result with the same test_type already exists for this appointment.';
    END IF;
END;

