create definer = root@localhost trigger Payments_NoPayAllCancel
    before insert
    on payments
    for each row
BEGIN
    DECLARE cancelled_count INT;
    DECLARE num_tests INT;

    -- Count the number of Results with status 'Cancelled'
    SELECT COUNT(*) INTO cancelled_count
    FROM Results
    WHERE appointment_id = NEW.appointment_id AND status = 'Canceled';
	
    SELECT num_tests INTO num_tests
    FROM Appointments
    WHERE NEW.appointment_id = appointment_id;
    -- Check if all Results are cancelled
    IF cancelled_count = num_tests THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot create payment: all results are cancelled.';
    END IF;
END;

